create function to_timestamp(double precision)
  returns timestamp with time zone
immutable
strict
cost 1
language sql
as $$
select ('epoch'::pg_catalog.timestamptz + $1 * '1 second'::pg_catalog.interval)
$$;

comment on function to_timestamp(double precision)
is 'convert UNIX epoch to timestamptz';

alter function to_timestamp(double precision)
  owner to postgres;

